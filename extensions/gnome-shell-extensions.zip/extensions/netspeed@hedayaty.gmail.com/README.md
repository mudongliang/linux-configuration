### Extension to show internet usage speed on gnome

* Check prefences to adjust the sizes

* Use middle click to toggle showing sum.

* If you are getting it from source:
    - to install
    ```make install```

    - to enable
    ```make enable```

    - to disable
    ```make disable```

    - to reload
    ```make reload```
